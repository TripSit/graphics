Naut
===============

Naut is a css theme you can use on reddit.com. It's free to use and any subreddit can use and edit it. Visit /r/Naut to preview the theme.

![Naut as used on /r/Google](http://i.imgur.com/nvIg7Vv.jpg)


Installation Instructions
===============

'Subreddit' should be changed to your subreddit name.

  1. Go to /r/subreddit/about/stylesheet
  2. Paste the CSS from the Naut 3 Main CSS File.css file into the css textarea.
  3. Upload the images from the /images/ folder. (Don't rename them!)
  4. Hit save!
  5. Go to /r/subreddit/about/edit and in the text-fields under "content options" fill in both "Submit new content" or something similiar that shows on the submission button.


Now you can customize it by either adding customization lines yourself, or by visiting the /r/Naut wiki and customizing it yourself!

If you have any questions on how to customize, /r/csshelp might be better suited than me!


##[Click here to download](https://github.com/Axel--/Naut-for-reddit/archive/master.zip)
